/*
  Carlos Pineda Guerrero, octubre 2023
*/

package servicio_json;

public class ParamModificaUsuario 
{
  Usuario usuario;
}
